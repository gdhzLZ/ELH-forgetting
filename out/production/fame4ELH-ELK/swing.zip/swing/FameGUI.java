package swing;

public class FameGUI {
	public static void main(String[] args) {
		new MainWindow().run();
	}
}
